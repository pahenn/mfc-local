<#
.SYNOPSIS
    Fetch metadata files from a reMarkable tablet over USB/SSH.
.DESCRIPTION
    Copies .metadata, .content, and .pagedata files for every document
    on the device to a local directory, preserving the UUID filenames.
    No Python required — runs on any Windows 10+ machine with OpenSSH.

    Reads REMARKABLE_PASSWORD from a .env file (if present) to avoid
    password prompts. Uses a single SSH+tar session for transfer.
.PARAMETER Host
    Tablet IP address (default: 10.11.99.1 for USB connection)
.PARAMETER User
    SSH username (default: root)
.PARAMETER OutputDir
    Local directory for downloaded files (default: .\backup)
.PARAMETER DryRun
    List files without copying
.EXAMPLE
    .\remarkable_metadata.ps1
    .\remarkable_metadata.ps1 -DryRun
    .\remarkable_metadata.ps1 -OutputDir "C:\Users\me\Desktop\rm_backup"
#>

param(
    [string]$Host = "10.11.99.1",
    [string]$User = "root",
    [string]$OutputDir = (Join-Path $PSScriptRoot "backup"),
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

$RemoteDocsPath = "/home/root/.local/share/remarkable/xochitl"
$Extensions = @(".metadata", ".content", ".pagedata")

# --- Load .env file ---
$envFile = Join-Path $PSScriptRoot ".env"
$Password = $null

if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        $line = $_.Trim()
        if ($line -and -not $line.StartsWith("#") -and $line.Contains("=")) {
            $key, $value = $line -split "=", 2
            if ($key.Trim() -eq "REMARKABLE_PASSWORD" -and $value.Trim()) {
                $Password = $value.Trim()
            }
        }
    }
}

if ($Password) {
    Write-Host "Using password from .env file"
} else {
    Write-Host "No .env password found - SSH will prompt for password"
}

# --- Check that ssh is available ---
if (-not (Get-Command "ssh" -ErrorAction SilentlyContinue)) {
    Write-Error "ssh not found. Ensure OpenSSH is installed (Settings > Apps > Optional Features > OpenSSH Client)."
    exit 1
}

# --- Build SSH command helper ---
function Get-SshBaseCmd {
    param([string]$RemoteCmd)

    if ($Password) {
        # Use SSH_ASKPASS to provide password without interactive prompt
        $askPassScript = Join-Path $env:TEMP "rm_askpass.bat"
        Set-Content -Path $askPassScript -Value "@echo $Password"

        $env:SSH_ASKPASS = $askPassScript
        $env:SSH_ASKPASS_REQUIRE = "force"
        $env:DISPLAY = "none"
    }

    return @("ssh", "-o", "StrictHostKeyChecking=no", "${User}@${Host}", $RemoteCmd)
}

# --- List metadata files on the device ---
Write-Host "Connecting to ${User}@${Host}..."
Write-Host "Scanning $RemoteDocsPath for metadata files...`n"

$findParts = ($Extensions | ForEach-Object { "-name `"*$_`"" }) -join " -o "
$findCmd = "find $RemoteDocsPath -maxdepth 1 \( $findParts \) -type f"

$sshArgs = Get-SshBaseCmd -RemoteCmd $findCmd
$sshOutput = & $sshArgs[0] $sshArgs[1..($sshArgs.Count-1)] 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Error "SSH failed: $sshOutput"
    exit 1
}

$remoteFiles = ($sshOutput -split "`n") | Where-Object { $_.Trim() -ne "" }

if ($remoteFiles.Count -eq 0) {
    Write-Host "No metadata files found on the device."
    exit 0
}

# --- Count by extension ---
foreach ($ext in $Extensions) {
    $count = ($remoteFiles | Where-Object { $_ -like "*$ext" }).Count
    Write-Host "  Found $count $ext files"
}
Write-Host "`n  Total: $($remoteFiles.Count) files"

# --- Dry run exit ---
if ($DryRun) {
    Write-Host "`nFiles that would be copied:"
    foreach ($f in $remoteFiles) {
        Write-Host "  $(Split-Path $f -Leaf)"
    }
    Write-Host "`nDry run - no files copied."
    exit 0
}

# --- Copy files via single SSH+tar session ---
if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
}

Write-Host "`nCopying to $OutputDir..."

$globs = ($Extensions | ForEach-Object { "*$_" }) -join " "
$tarCmd = "cd $RemoteDocsPath && tar cf - $globs 2>/dev/null"

$sshArgs = Get-SshBaseCmd -RemoteCmd $tarCmd
$tarFile = Join-Path $env:TEMP "rm_metadata.tar"

Write-Host "  Streaming files via tar..."
& $sshArgs[0] $sshArgs[1..($sshArgs.Count-1)] 2>$null | Set-Content -Path $tarFile -AsByteStream

# Extract tar - Windows 10+ has tar built-in
& tar xf $tarFile -C $OutputDir 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Warning "tar extract returned exit code $LASTEXITCODE"
}

Remove-Item $tarFile -ErrorAction SilentlyContinue

# Clean up askpass script if created
$askPassScript = Join-Path $env:TEMP "rm_askpass.bat"
Remove-Item $askPassScript -ErrorAction SilentlyContinue

# --- Summary ---
$metadataFiles = Get-ChildItem -Path $OutputDir -Filter "*.metadata" | Sort-Object Name

Write-Host "`n$('=' * 60)"
Write-Host "Downloaded $($metadataFiles.Count) documents`n"

foreach ($mf in $metadataFiles) {
    try {
        $data = Get-Content $mf.FullName -Raw | ConvertFrom-Json
        $name = if ($data.visibleName) { $data.visibleName } else { "(unknown)" }
        $label = if ($data.type -eq "CollectionType") { "FOLDER" } else { "DOC" }
        $status = if ($data.deleted) { " [DELETED]" } else { "" }
        $location = ""
        if ($data.parent -eq "trash") {
            $location = " (in: trash)"
        } elseif ($data.parent) {
            $location = " (in: $($data.parent.Substring(0, [Math]::Min(8, $data.parent.Length)))...)"
        }
        Write-Host "  [$label] ${name}${status}${location}"
    } catch {
        Write-Host "  [?] $($mf.Name) (could not parse)"
    }
}

Write-Host "`nFiles saved to: $OutputDir"
